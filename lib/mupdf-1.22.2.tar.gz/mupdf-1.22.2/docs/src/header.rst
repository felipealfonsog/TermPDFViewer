.. raw:: html

   <div class="discordLink"><a href="https://discord.gg/DQjvZ6ERqH" target=_blank>Find <b>#mupdf</b> on <b>Discord</b><img src="_images/discord-mark-blue.svg" alt="Discord logo" /></a></div>

   <div class="feedbackLink"><a id="feedbackLinkTop" target=_blank>Do you have any feedback on this page?</b></a></div>

   <script>

   var url_string = window.location.href;
   var a = document.getElementById('feedbackLinkTop');
   a.setAttribute("href", "https://artifex.com/contributor/feedback.php?url="+url_string);

   </script>
