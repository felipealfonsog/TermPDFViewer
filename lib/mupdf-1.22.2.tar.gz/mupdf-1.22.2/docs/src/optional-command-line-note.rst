.. note::

   Command line parameters within square brackets `[]` are optional.
